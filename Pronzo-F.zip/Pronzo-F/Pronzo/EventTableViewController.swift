//
//  EventTableViewController.swift
//  Pronzo
//
//  Created by Surya Ruddaraju on 5/25/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import os.log

struct cellData {
    let name : String!
    let image : UIImage!
    let interest : String!
    let time : String!
    let location : String!
    let eventID: String!
}

class EventTableViewController: UITableViewController {
    
    let backgroundImage = UIImage(named: "BG_purple_gradient")
    let storage = FIRStorage.storage().reference()
    var CurrentUser: FIRUser!
    var arrayOfCellData = [cellData]()
    var DisplayPicture = UIImage()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.populateEventTable()
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let imageView = UIImageView(image: backgroundImage)
        self.tableView.backgroundView = imageView
        self.tableView.tableFooterView = UIView(frame: CGRect.zero)
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayOfCellData.count;
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("EventTableViewCell", owner: self, options: nil)?.first as! EventTableViewCell
        cell.backgroundColor = UIColor(white: 1, alpha: 0.2)
        cell.selectionStyle = .none
        cell.picture.image = arrayOfCellData[indexPath.row].image
        cell.name.text = arrayOfCellData[indexPath.row].name
        cell.time.text = arrayOfCellData[indexPath.row].time
        cell.location.text = arrayOfCellData[indexPath.row].location
        return cell;
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 84;
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "eventDetail", sender: indexPath.row)
    }

    private func populateEventTable() {
        self.CurrentUser = FIRAuth.auth()?.currentUser
        self.arrayOfCellData.removeAll()
        let storage = FIRStorage.storage().reference()
        let OwnerImageRef = storage.child(CurrentUser.uid)
        OwnerImageRef.data(withMaxSize: 25*1000*1000) { (data, error) in
            if error == nil{
                self.DisplayPicture = UIImage(data: data!)!
                print("Successful image link INSIDE loadEventTable()")
                self.loadEventTable()
            } else {
                print(error ?? "Error")
                print("Failed to link image")
            }
        }
    }
    
    private func loadEventTable(){
        let ref = FIRDatabase.database().reference()
        var name = ""
        ref.child("events").observe(.value, with: { (snapshot) in
            self.arrayOfCellData.removeAll()
            for i in (snapshot.value as! NSDictionary) {
                let currEventID = i.key as! String
                let val = i.value
                // let OwnerID = (val as! NSDictionary)["OwnerID"] as! String
                let email = (val as! NSDictionary)["Email"] as! String
                let fname = (val as! NSDictionary)["FirstName"] as! String
                let lname = (val as! NSDictionary)["LastName"] as! String
                let date  = (val as! NSDictionary)["Date"] as! String
                let rname = (val as! NSDictionary)["RestaurantName"] as! String
                name = fname + " " + lname
                self.arrayOfCellData.append(cellData(name: name, image: self.DisplayPicture, interest: email, time: date, location: rname, eventID: currEventID))
            }
            self.tableView.reloadData()
        })
    }
    
    // MARK: Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        NSLog("in segue")
        if segue.identifier == "eventDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let object = arrayOfCellData[indexPath.row]
                let controller = segue.destination  as! EventDetailViewController
                controller.detailItem = object
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
}
