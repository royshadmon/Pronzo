//
//  ProfileViewController.swift
//  Pronzo
//
//  Created by Dean Rabinowitz on 5/31/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class ProfileViewController: UIViewController {
    
    //MARK: Properties
    let UserRef = FIRDatabase.database().reference(withPath: "users")
    let userID : String = (FIRAuth.auth()?.currentUser?.uid)!
    var CurrentUser: FIRUser!
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    @IBOutlet weak var bioLabel: UITextView!
    @IBOutlet weak var firstNameView: UIView!
    @IBOutlet weak var lastNameView: UIView!
    @IBOutlet weak var usernameView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var bioView: UIView!
    @IBOutlet weak var ProfilePicture: UIImageView!
    
    //Mark: Views
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "BG_purple_gradient")!)
        let storage = FIRStorage.storage().reference()
        let tempImageRef = storage.child(userID)
        tempImageRef.data(withMaxSize: 25*1000*1000) { (data, error) in
            if error == nil{
                self.ProfilePicture.image = UIImage(data: data!)!
                print("Successful image link")
            } else {
                print(error ?? "Error")
                print("Failed to link image")
            }
        }
        
        UserRef.child(userID).observe(.value, with: { snapshot in
            let userName = (snapshot.value as! NSDictionary)["Username"] as! String
            let firstName = (snapshot.value as! NSDictionary)["FirstName"] as! String
            let lastName = (snapshot.value as! NSDictionary)["LastName"] as! String
            let email = (snapshot.value as! NSDictionary)["Email"] as! String
            let bio = (snapshot.value as! NSDictionary)["Bio"] as! String
            self.userNameLabel.text = userName
            self.firstNameLabel.text = firstName
            self.lastNameLabel.text = lastName
            self.emailLabel.text = email
            self.bioLabel.text = bio
            self.navigationItem.title = userName
        } )
    }
    
    override func viewWillAppear(_ animated: Bool) {
        firstNameView.layer.cornerRadius = 5
        firstNameView.layer.masksToBounds = true
        lastNameView.layer.cornerRadius = 5
        lastNameView.layer.masksToBounds = true
        usernameView.layer.cornerRadius = 5
        usernameView.layer.masksToBounds = true
        emailView.layer.cornerRadius = 5
        emailView.layer.masksToBounds = true
        bioView.layer.cornerRadius = 5
        bioView.layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func SignOutButtonWasPressed(_ sender: Any) {
        do{
            try FIRAuth.auth()?.signOut()
            self.performSegue(withIdentifier: "UserDidSignOut", sender: nil)
        } catch let signOutError as NSError {
            print("Error signing out: \(signOutError)")
        } catch {
            print("Unknown error")
        }
    }
}
