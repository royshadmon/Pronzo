//
//  UITableViewController+Events.h
//  Pronzo
//
//  Created by Surya Ruddaraju on 4/19/17.
//  Copyright © 2017 com.example. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewController (Events)

@end
