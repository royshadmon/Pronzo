//
//  Event.swift
//  Pronzo
//
//  Created by Roy Shadmon on 5/23/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import UIKit

struct Event {
    let RestaurantName: String
    let FirstName: String
    let LastName: String
    let Date: String
    let Email: String
    let OwnerID: String
    let UsersAttending: Array<String>
    let ref: FIRDatabaseReference?
    
    init(RestaurantName: String, FirstName: String, LastName: String, Date: String, Email: String, OwnerID: String, UsersAttending: Array<String>) {
        self.RestaurantName = RestaurantName
        self.FirstName = FirstName
        self.LastName = LastName
        self.Date = Date
        self.Email = Email
        self.OwnerID = OwnerID
        self.UsersAttending = UsersAttending
        self.ref = nil
    }
    
    func toAnyObject() -> Any {
        return [
            "RestaurantName": RestaurantName,
            "FirstName": FirstName,
            "LastName": LastName,
            "Date": Date,
            "Email": Email,
            "OwnerID": OwnerID,
            "UsersAttending": UsersAttending
        ]
    }
}
