//
//  UITableViewController+Events.m
//  Pronzo
//
//  Created by Surya Ruddaraju on 4/19/17.
//  Copyright © 2017 com.example. All rights reserved.
//

#import "UITableViewController+Events.h"

@implementation UITableViewController (Events)

@end
