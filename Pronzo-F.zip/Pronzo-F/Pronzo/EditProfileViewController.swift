//
//  EditProfileViewController.swift
//  Pronzo
//
//  Created by Dean Rabinowitz on 6/5/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class EditProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextFieldDelegate, UITextViewDelegate {
    
    //MARK: Properties
    @IBOutlet weak var UsernameText: UITextField!
    @IBOutlet weak var FirstNameText: UITextField!
    @IBOutlet weak var LastNameText: UITextField!
    @IBOutlet weak var BioText: UITextView!
    @IBOutlet weak var ProfilePicture: UIImageView!
    
    // Views
    @IBOutlet weak var LastNameView: UIView!
    @IBOutlet weak var UsernameView: UIView!
    @IBOutlet weak var BioView: UIView!
    @IBOutlet weak var FirstNameView: UIView!
    
    let ImagePicker = UIImagePickerController()
    
    let UserRef = FIRDatabase.database().reference(withPath: "users")
    let userID : String = (FIRAuth.auth()?.currentUser?.uid)!
    var CurrentUser: FIRUser!
    var CurrentEmail = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ImagePicker.delegate = self
        FirstNameText.delegate = self
        LastNameText.delegate = self
        UsernameText.delegate = self
        BioText.delegate = self
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "BG_purple_gradient")!)
        let storage = FIRStorage.storage().reference()
        let tempImageRef = storage.child(userID)
        print("full path to Image: "+tempImageRef.fullPath)
        print("name of Image: "+tempImageRef.name)
        tempImageRef.data(withMaxSize: 25*1000*1000) { (data, error) in
            if error == nil{
                self.ProfilePicture.image = UIImage(data: data!)!
                print("Successful image link")
            } else {
                print(error ?? "Error")
                print("Failed to link image")
            }
        }
        
        UserRef.child(userID).observe(.value, with: { snapshot in
            let CurrentUserName = (snapshot.value as! NSDictionary)["Username"] as! String
            let CurrentFirstName = (snapshot.value as! NSDictionary)["FirstName"] as! String
            let CurrentLastName = (snapshot.value as! NSDictionary)["LastName"] as! String
            let CurrentBio = (snapshot.value as! NSDictionary)["Bio"] as! String
            self.CurrentEmail = (snapshot.value as! NSDictionary)["Email"] as! String
            self.UsernameText.text = CurrentUserName
            self.FirstNameText.text = CurrentFirstName
            self.LastNameText.text = CurrentLastName
            self.BioText.text = CurrentBio
            self.navigationItem.title = CurrentUserName
        } )
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if(text == "\n") {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        LastNameView.layer.cornerRadius = 5
        LastNameView.layer.masksToBounds = true
        UsernameView.layer.cornerRadius = 5
        UsernameView.layer.masksToBounds = true
        BioView.layer.cornerRadius = 5
        BioView.layer.masksToBounds = true
        FirstNameView.layer.cornerRadius = 5
        FirstNameView.layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Functions
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String: Any]) {
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Error with picking image")
        }
        ProfilePicture.image = image
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func UploadPhotoAndFinish() {
        let storage = FIRStorage.storage().reference()
        let TempImageRef = storage.child((FIRAuth.auth()?.currentUser?.uid)!)
        let Image = ProfilePicture.image
        let MetaData = FIRStorageMetadata()
        MetaData.contentType = "image/png"
        TempImageRef.put(UIImagePNGRepresentation(Image!)!, metadata: MetaData) { (data,error) in
            if error == nil{
                print("Upload successful!")
                self.dismiss(animated: true, completion: nil)
            }else{
                print(error?.localizedDescription as Any)
            }
        }
    }
    
    // MARK: Action
    @IBAction func DoneButtonWasPressed(_ sender: UIBarButtonItem) {
        UserRef.child(userID).child("FirstName").setValue(FirstNameText.text)
        UserRef.child(userID).child("LastName").setValue(LastNameText.text)
        UserRef.child(userID).child("Username").setValue(UsernameText.text)
        UserRef.child(userID).child("Bio").setValue(BioText.text)
        self.UploadPhotoAndFinish()
    }

    @IBAction func ChangeProfilePicture(_ sender: UIButton) {
        print("In Load Image")
        ImagePicker.allowsEditing = false
        ImagePicker.sourceType = .photoLibrary
        present(ImagePicker, animated: true, completion: nil)
    }
    
    // MARK: - Navigation
    @IBAction func CancelWasPressed(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
    }
}
