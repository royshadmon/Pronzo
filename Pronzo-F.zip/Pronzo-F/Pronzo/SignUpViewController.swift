//
//  SignUpViewController.swift
//  Pronzo
//
//  Created by Roy Shadmon on 5/4/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth


class SignUpViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    // MARK: Variables
    
    @IBOutlet var FirstName: UITextField!
    @IBOutlet var LastName: UITextField!
    @IBOutlet var Username: UITextField!
    @IBOutlet var Email: UITextField!
    @IBOutlet var Password: UITextField!
    @IBOutlet weak var ProfilePicture: UIImageView!
    let RootRef = FIRDatabase.database().reference()
    let UserRef = FIRDatabase.database().reference(withPath: "users")
    var CurrentUser: FIRUser!
    let ImagePicker = UIImagePickerController()
    
    // MARK: Functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ImagePicker.delegate = self
        FirstName.delegate = self
        LastName.delegate = self
        Username.delegate = self
        Email.delegate = self
        Password.delegate = self
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "BG_purple_gradient")!)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String: Any]) {
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Error with picking image")
        }
        ProfilePicture.image = image
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func CreateFirebaseUser() {
        FIRAuth.auth()?.createUser(withEmail: self.Email.text!, password: self.Password.text!){
            (user, error) in
            if error == nil {
                print("Account Created")
                // self.FinishAccountCreation()
                self.CurrentUser = FIRAuth.auth()?.currentUser
                self.RecordData()
            }
            else {
                print("Account not Created")
                let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    func TextFieldMissing() {
        let alertController = UIAlertController(title: "Create account error", message: "Please fill in all text fields", preferredStyle: UIAlertControllerStyle.alert)
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func UploadPhotoAndFinish() {
        let storage = FIRStorage.storage().reference()
        let TempImageRef = storage.child((FIRAuth.auth()?.currentUser?.uid)!)
        let Image = ProfilePicture.image
        let MetaData = FIRStorageMetadata()
        MetaData.contentType = "image/png"
        TempImageRef.put(UIImagePNGRepresentation(Image!)!, metadata: MetaData) { (data,error) in
            if error == nil{
                print("Upload successful!")
                self.performSegue(withIdentifier: "CreateAccount", sender: nil)
            }else{
                print(error?.localizedDescription as Any)
            }
        }
    }
    
    func RecordData() {
        let CurrentUserInfo = User(FirstName: FirstName.text!,
                                   LastName: LastName.text!,
                                   Username: Username.text!,
                                   Email: Email.text!,
                                   Bio: "Hi! My name is "+FirstName.text! + "."
            /*MyEvents: Array(repeating: "", count: 0),
             EventsAttending: Array(repeating: "", count: 0)*/)
        let CurrentUserRef = self.UserRef.child(CurrentUser.uid)
        CurrentUserRef.setValue(CurrentUserInfo.toAnyObject())
        CurrentUserRef.child("MyEvents").setValue(Array(repeating: "", count: 1))
        CurrentUserRef.child("EventsAttending").setValue(Array(repeating: "", count: 1))
        self.UploadPhotoAndFinish()
    }
    
    func CheckTextFields() {
        let alertController = UIAlertController(title: "Create account error", message: "Please fill in all text fields", preferredStyle: UIAlertControllerStyle.alert)
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func FinishAccountCreation() {
        self.CurrentUser = FIRAuth.auth()?.currentUser
        self.RecordData()
        self.performSegue(withIdentifier: "CreateAccount", sender: nil)
    }
    
    // MARK: Actions
    @IBAction func LoadImage(_ sender: UIButton) {
//        print("In Load Image")
        ImagePicker.allowsEditing = false
        ImagePicker.sourceType = .photoLibrary
        
        present(ImagePicker, animated: true, completion: nil)
    }
    
    @IBAction func SignUpButton(_ sender: Any) {
        print("Create Account Button Pressed")
        if FirstName.text == "" || LastName.text == "" || Username.text == "" || Email.text == "" || Password.text == "" {
            TextFieldMissing()
        }
        else {
            CreateFirebaseUser()
        }
    }
    
}
