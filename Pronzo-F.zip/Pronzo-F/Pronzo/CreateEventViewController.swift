//
//  CreateEventViewController.swift
//  Pronzo
//
//  Created by Surya Ruddaraju on 4/27/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import os.log

class CreateEventViewController: UIViewController, UITextFieldDelegate {
    
    //MARK: Properties
    var event: Event?
    @IBOutlet weak var doneButton: UIBarButtonItem!
    @IBOutlet var RestaurantName: UITextField!
    @IBOutlet var datePicker: UIDatePicker!
    let EventReference = FIRDatabase.database().reference(withPath: "events")
    let UserRef = FIRDatabase.database().reference(withPath: "users")
    let ref = FIRDatabase.database().reference()
    var StringDate = "dd-MM-yyy HH:mm"
    let userID : String = (FIRAuth.auth()?.currentUser?.uid)!

    //MARK: Override functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "BG_purple_gradient")!)
        self.datePicker.setValue(UIColor.white, forKeyPath: "textColor")
        RestaurantName.text = ""
        RestaurantName.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Functions
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func CancelCreateEvent(_ sender: UIBarButtonItem) {
        self.performSegue(withIdentifier: "LeavingCreateEventPage", sender: nil)
    }
    
    
    func TextFieldMissing() {
        let alertController = UIAlertController(title: "Create event error", message: "Please fill in all text fields", preferredStyle: UIAlertControllerStyle.alert)
        let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func datePickerChanged(sender: Any) {
        let Date = DateFormatter()
        Date.dateStyle = DateFormatter.Style.short
        Date.timeStyle = DateFormatter.Style.short
        StringDate = Date.string(from: datePicker.date)
        print (StringDate)
    }
    
    func getUserInfo() {
        print("inside genuserinfo")
        UserRef.child(userID).observe(.value, with: { (snapshot) in
            let FirstName = (snapshot.value as! NSDictionary)["FirstName"] as! String
            let type = type(of: FirstName)
            print (type)
        })
        
    }
    
    @IBAction func DoneButtonWasPressed(_ sender: Any) {
        print("Create event button pressed")
        let Restaurant = RestaurantName.text!
        if RestaurantName.text == "" {
            TextFieldMissing()
            print ("inside if")
        }
        else {
            UserRef.child(userID).observeSingleEvent(of: .value, with: { (snapshot) in
                let Email = (snapshot.value as! NSDictionary)["Email"] as! String
                let FirstName = (snapshot.value as! NSDictionary)["FirstName"] as! String
                let LastName = (snapshot.value as! NSDictionary)["LastName"] as! String
                let EventInfo = Event(RestaurantName: Restaurant,
                                      FirstName: FirstName,
                                      LastName: LastName,
                                      Date: self.StringDate,
                                      Email: Email,
                                      OwnerID: self.userID,
                                      UsersAttending: Array(repeating: self.userID, count: 1))
                let CurrentEventReference = self.EventReference.childByAutoId()
                CurrentEventReference.setValue(EventInfo.toAnyObject())
                let MyEventsArray = (snapshot.value as! NSDictionary)["MyEvents"] as! NSMutableArray
                MyEventsArray.add(CurrentEventReference.key)
                self.UserRef.child(self.userID).child("MyEvents").setValue(MyEventsArray);
                
            })
            self.performSegue(withIdentifier: "LeavingCreateEventPage", sender: nil)
        }
    }
}
