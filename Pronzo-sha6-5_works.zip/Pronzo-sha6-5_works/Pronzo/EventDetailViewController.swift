//
//  EventDetailViewController.swift
//  Pronzo
//
//  Created by Surya Ruddaraju on 4/24/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import UIKit
import Firebase

class EventDetailViewController: UIViewController {
    
    
    // MARK: Properties
    @IBOutlet var theLabel: UILabel!
    let userID : String = (FIRAuth.auth()?.currentUser?.uid)!
    let EventRef = FIRDatabase.database().reference(withPath: "events")
    let UserRef = FIRDatabase.database().reference(withPath: "users")
    @IBOutlet weak var UsersAttendingList: UITextView!
    
    // Views
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var locationView: UIView!
    @IBOutlet weak var timeView: UIView!
    @IBOutlet weak var emailView: UIView!
    
    // Second Label
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!
    
    override func viewDidLoad() {
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "BG_purple_gradient")!)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        if let detail = detailItem {
            if let label = nameLabel {
                label.text = detail.name
            }
            if let label = locationLabel {
                navigationItem.title = detail.location
                label.text = detail.location
            }
            if let label = timeLabel {
                label.text = detail.time
            }
            if let label = emailLabel {
                label.text = detail.interest
            }
            if let label = theLabel {
                label.text = ""
            }
        }
        
        let eventID = detailItem?.eventID
        //print("Event: ", eventID)
        EventRef.child(eventID!).observeSingleEvent(of: .value, with: { snapshot in
            let AttendingUsersArray = (snapshot.value as! NSDictionary)["UsersAttending"] as! NSMutableArray
            var temptext = ""
            for i in AttendingUsersArray {
                let userID = i as! String
                print("Users: ", userID, "\n")
                self.UserRef.child(userID).observeSingleEvent(of: .value, with: { snapshot in
                    let fname = (snapshot.value as! NSDictionary)["FirstName"] as! String
                    let lname = (snapshot.value as! NSDictionary)["LastName"] as! String
                    temptext += fname + " " + lname + "\n"
                    self.UsersAttendingList.text = temptext
                } )
            }
        } )

        theLabel.isHidden = true
        
        // Add border radius
        nameView.layer.cornerRadius = 5
        nameView.layer.masksToBounds = true
        locationView.layer.cornerRadius = 5
        locationView.layer.masksToBounds = true
        timeView.layer.cornerRadius = 5
        timeView.layer.masksToBounds = true
        emailView.layer.cornerRadius = 5
        emailView.layer.masksToBounds = true

    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var detailItem: cellData? {
        didSet {
            // Update the view.
//            configureView()
        }
    }
    
    // MARK: Actions
    @IBAction func JoinButtonWasPressed(_ sender: Any) {
        let eventID = detailItem?.eventID
        //print("eventID: ", detailItem?.eventID)
        print("userID: ", userID)
        EventRef.child(eventID!).observeSingleEvent(of: .value, with: { snapshot in
            let AttendingUsersArray = (snapshot.value as! NSDictionary)["UsersAttending"] as! NSMutableArray
            print("before: ", AttendingUsersArray)
            if !AttendingUsersArray.contains(self.userID) {
                AttendingUsersArray.add(self.userID)
            }
            print("after: ", AttendingUsersArray)
            self.EventRef.child(eventID!).child("UsersAttending").setValue(AttendingUsersArray)
        } )
        UserRef.child(self.userID).observeSingleEvent(of: .value, with: { snapshot in
            let EventsAttendingArray = (snapshot.value as! NSDictionary)["EventsAttending"] as! NSMutableArray
            EventsAttendingArray.add(eventID as Any)
            self.UserRef.child(self.userID).child("EventsAttending").setValue(EventsAttendingArray);
        } )
    }
    
    
}

