//
//  User.swift
//  Pronzo
//
//  Created by Roy Shadmon on 5/23/17.
//  Copyright © 2017 com.example. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import UIKit

struct User {
    let FirstName: String
    let LastName: String
    let Username: String
    let Email: String
    let Bio: String
    let ref: FIRDatabaseReference?
    //Note: not recording password for better security.
    
    init(FirstName: String, LastName: String, Username: String, Email: String, Bio: String) {
        self.FirstName = FirstName
        self.LastName = LastName
        self.Username = Username
        self.Email = Email
        self.Bio = Bio
        self.ref = nil
    }
    
    //    init(snapshot: FIRDataSnapshot) {
    //        FirstName = snapshot.FirstName
    //        LastName = snapshot.LastName
    //        Username = snapshot.Username
    //        Email = snapshot.Email
    //        ref = snapshot.ref
    ////        FirstName = snapshot.FirstName
    ////        let snapshotValue = snapshot.value as! [String: AnyObject]
    //    }
    
    func toAnyObject() -> Any {
        return [
            "FirstName": FirstName,
            "LastName": LastName,
            "Username": Username,
            "Email": Email,
            "Bio": Bio
        ]
    }
    
}
